package hilos;

public class Triangulo {

}
