package hilos;

public class Rectangulo {

}
